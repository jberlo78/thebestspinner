.. tbs documentation master file, created by
   sphinx-quickstart on Sun Nov  7 21:51:04 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tbs's documentation!
===============================

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: tbs

.. autoclass:: Api 
    :members: 

.. autoclass:: AuthenticationError
    :members: 

.. autoclass:: QuotaUsedError
    :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

